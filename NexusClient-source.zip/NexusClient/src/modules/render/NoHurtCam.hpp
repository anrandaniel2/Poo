#pragma once
#include "../Module.hpp"

namespace Nexus {

class NoHurtCam : public Module {
public:
    NoHurtCam() : Module("NoHurtCam", "Removes camera shake when damaged",
                         Category::Render) {
        SetColor(0.8f, 0.6f, 0.3f);
    }
    
    void OnEnable() override;
    void OnDisable() override;
};

} // namespace Nexus
