#pragma once
#include "../Module.hpp"

namespace Nexus {

class Fullbright : public Module {
public:
    Fullbright() : Module("Fullbright", "Maximum brightness everywhere",
                          Category::Render) {
        AddFloat("Brightness", 1.0f, 0.5f, 1.0f, 0.05f, "");
        SetColor(1.0f, 1.0f, 0.4f);
    }
    
    void OnEnable() override;
    void OnDisable() override;
};

} // namespace Nexus
