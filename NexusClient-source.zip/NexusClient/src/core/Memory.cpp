#include "Memory.hpp"
#include "ObfString.hpp"
#include <android/log.h>
#include <dlfcn.h>
#include <sys/mman.h>
#include <unistd.h>
#include <fstream>
#include <sstream>
#include <algorithm>
#include <cstring>

#define LOGI(...) __android_log_print(ANDROID_LOG_INFO, "NexusMemory", __VA_ARGS__)
#define LOGE(...) __android_log_print(ANDROID_LOG_ERROR, "NexusMemory", __VA_ARGS__)

namespace Nexus {

uintptr_t Memory::s_baseAddress = 0;
uintptr_t Memory::s_textStart = 0;
uintptr_t Memory::s_textEnd = 0;
std::unordered_map<std::string, uintptr_t> Memory::s_cache;

void Memory::Init(void* moduleHandle) {
    // Get base address from /proc/self/maps
    std::ifstream maps(OBF("/proc/self/maps"));
    std::string line;
    
    while (std::getline(maps, line)) {
        if (line.find(OBF("libminecraftpe.so")) != std::string::npos) {
            // Parse first address range
            size_t dash = line.find('-');
            if (dash != std::string::npos) {
                s_baseAddress = std::stoull(line.substr(0, dash), nullptr, 16);
                
                // Find executable section for scanning
                if (line.find("r-xp") != std::string::npos ||
                    line.find("r--p") != std::string::npos) {
                    if (s_textStart == 0) {
                        s_textStart = s_baseAddress;
                    }
                    size_t space = line.find(' ');
                    s_textEnd = std::stoull(
                        line.substr(dash + 1, space - dash - 1), nullptr, 16);
                }
            }
            break;
        }
    }
    
    LOGI(OBF("Base: 0x%lx, Text: 0x%lx - 0x%lx (%lu MB)"),
         s_baseAddress, s_textStart, s_textEnd,
         (s_textEnd - s_textStart) / (1024 * 1024));
}

std::pair<std::vector<uint8_t>, std::vector<bool>>
Memory::ParsePattern(const std::string& signature) {
    std::vector<uint8_t> bytes;
    std::vector<bool> mask;  // true = match, false = wildcard
    
    std::istringstream stream(signature);
    std::string token;
    
    while (stream >> token) {
        if (token == "??" || token == "?") {
            bytes.push_back(0);
            mask.push_back(false);
        } else {
            bytes.push_back(static_cast<uint8_t>(
                std::stoul(token, nullptr, 16)));
            mask.push_back(true);
        }
    }
    
    return {bytes, mask};
}

uintptr_t Memory::SigScan(const std::string& signature) {
    auto [pattern, mask] = ParsePattern(signature);
    size_t patLen = pattern.size();
    
    if (patLen == 0 || s_textStart == 0) return 0;
    
    const uint8_t* scanStart = reinterpret_cast<const uint8_t*>(s_textStart);
    const uint8_t* scanEnd   = reinterpret_cast<const uint8_t*>(s_textEnd - patLen);
    
    // Optimized scan: check first byte before inner loop
    uint8_t firstByte = pattern[0];
    bool firstIsWild = !mask[0];
    
    for (const uint8_t* ptr = scanStart; ptr < scanEnd; ++ptr) {
        if (firstIsWild || *ptr == firstByte) {
            bool found = true;
            for (size_t i = 1; i < patLen; ++i) {
                if (mask[i] && ptr[i] != pattern[i]) {
                    found = false;
                    break;
                }
            }
            if (found) {
                uintptr_t result = reinterpret_cast<uintptr_t>(ptr);
                LOGI(OBF("SigScan hit at 0x%lx (offset 0x%lx)"),
                     result, result - s_baseAddress);
                return result;
            }
        }
    }
    
    LOGE(OBF("SigScan failed for pattern: %s"), signature.c_str());
    return 0;
}

uintptr_t Memory::SigScanCached(const std::string& name,
                                 const std::string& signature) {
    auto it = s_cache.find(name);
    if (it != s_cache.end()) return it->second;
    
    uintptr_t result = SigScan(signature);
    if (result) s_cache[name] = result;
    return result;
}

template<typename T>
void Memory::Write(uintptr_t address, T value) {
    if (Unprotect(address, sizeof(T))) {
        *reinterpret_cast<T*>(address) = value;
    }
}

bool Memory::WriteBytes(uintptr_t address, const std::vector<uint8_t>& bytes) {
    if (!Unprotect(address, bytes.size())) return false;
    std::memcpy(reinterpret_cast<void*>(address), bytes.data(), bytes.size());
    return true;
}

bool Memory::Unprotect(uintptr_t address, size_t size) {
    uintptr_t pageSize = sysconf(_SC_PAGESIZE);
    uintptr_t pageStart = address & ~(pageSize - 1);
    size_t totalSize = (address - pageStart) + size;
    
    return mprotect(reinterpret_cast<void*>(pageStart),
                    totalSize,
                    PROT_READ | PROT_WRITE | PROT_EXEC) == 0;
}

uintptr_t Memory::DerefChain(uintptr_t base,
                              const std::vector<uintptr_t>& offsets) {
    uintptr_t addr = base;
    for (size_t i = 0; i < offsets.size(); ++i) {
        addr = Read<uintptr_t>(addr) + offsets[i];
        if (!addr) return 0;
    }
    return addr;
}

// Explicit template instantiations
template void Memory::Write<uint8_t>(uintptr_t, uint8_t);
template void Memory::Write<uint16_t>(uintptr_t, uint16_t);
template void Memory::Write<uint32_t>(uintptr_t, uint32_t);
template void Memory::Write<uint64_t>(uintptr_t, uint64_t);
template void Memory::Write<float>(uintptr_t, float);
template void Memory::Write<double>(uintptr_t, double);

} // namespace Nexus
