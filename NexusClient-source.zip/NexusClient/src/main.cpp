/**
 * NexusClient — Minecraft Bedrock Edition Client
 * Main entry point for libclient.so
 * Loaded by LeviLauncher on Android ARM64
 */

#include <jni.h>
#include <android/log.h>
#include <dlfcn.h>
#include <unistd.h>
#include <thread>

#include "core/Client.hpp"
#include "core/Hooks.hpp"
#include "core/Memory.hpp"
#include "core/ObfString.hpp"

#define LOG_TAG "NexusClient"
#define LOGI(...) __android_log_print(ANDROID_LOG_INFO,  LOG_TAG, __VA_ARGS__)
#define LOGE(...) __android_log_print(ANDROID_LOG_ERROR, LOG_TAG, __VA_ARGS__)

namespace Nexus {

/**
 * Main initialization thread.
 * Waits for Minecraft to fully load, then installs hooks
 * and initializes the module system.
 */
void InitThread() {
    LOGI(OBF("NexusClient v1.0.0 — Initializing..."));
    
    // Wait for libminecraftpe.so to load
    void* mcLib = nullptr;
    int attempts = 0;
    while (!mcLib && attempts < 120) {
        mcLib = dlopen(OBF("libminecraftpe.so"), RTLD_NOLOAD);
        if (!mcLib) {
            usleep(500000); // 500ms
            attempts++;
        }
    }
    
    if (!mcLib) {
        LOGE(OBF("Failed to find libminecraftpe.so after 60s"));
        return;
    }
    
    LOGI(OBF("Found libminecraftpe.so at %p"), mcLib);
    
    // Initialize memory scanner
    Memory::Init(mcLib);
    
    // Initialize the client (modules, config, GUI)
    Client::GetInstance().Init();
    
    // Install rendering and input hooks
    Hooks::InstallAll();
    
    LOGI(OBF("NexusClient initialized successfully!"));
}

} // namespace Nexus

/**
 * JNI_OnLoad — Called when the .so is loaded by the JVM.
 * Used by LeviLauncher for mod injection.
 */
extern "C" JNIEXPORT jint JNI_OnLoad(JavaVM* vm, void* reserved) {
    JNIEnv* env;
    if (vm->GetEnv(reinterpret_cast<void**>(&env), JNI_VERSION_1_6) != JNI_OK) {
        return JNI_ERR;
    }
    
    // Launch init on a separate thread to avoid blocking
    std::thread(Nexus::InitThread).detach();
    
    return JNI_VERSION_1_6;
}

/**
 * Constructor attribute — alternative entry for non-JNI loading.
 */
__attribute__((constructor))
void OnLibraryLoad() {
    LOGI(OBF("NexusClient .so loaded via constructor"));
    // JNI_OnLoad will handle the rest if loaded via JVM
}
