#pragma once
#include "../Module.hpp"

namespace Nexus {

class XRay : public Module {
public:
    XRay() : Module("XRay", "See ores through blocks",
                    Category::World) {
        AddFloat("Opacity", 0.3f, 0.0f, 1.0f, 0.05f, "",
                 "Non-ore block opacity");
        AddBool("Diamond", true);
        AddBool("Gold", true);
        AddBool("Iron", true);
        AddBool("Emerald", true);
        AddBool("Lapis", true);
        AddBool("Redstone", true);
        AddBool("Coal", false);
        AddBool("Ancient Debris", true);
        SetColor(0.2f, 1.0f, 0.8f);
    }
    
    void OnEnable() override;
    void OnDisable() override;
};

} // namespace Nexus
