#pragma once
#include "../Module.hpp"

namespace Nexus {

class Criticals : public Module {
public:
    Criticals() : Module("Criticals", "Forces critical hits on every attack",
                         Category::Combat) {
        AddMode("Mode", {"Packet", "Ground Spoof", "Jump"}, 0);
        SetColor(1.0f, 0.8f, 0.2f);
    }
    
    void OnEnable() override {}
    void OnDisable() override {}
    void OnAttack(void* gameMode, void* entity) override;
};

} // namespace Nexus
