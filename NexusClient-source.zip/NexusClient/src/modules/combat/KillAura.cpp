#include "KillAura.hpp"
#include "../../core/Memory.hpp"
#include "../../sdk/Actor.hpp"
#include "../../sdk/Player.hpp"
#include "../../sdk/Level.hpp"
#include "../../sdk/GameMode.hpp"

namespace Nexus {

void KillAura::OnEnable() {
    m_currentTarget = nullptr;
    m_attackTimer = 0.0f;
}

void KillAura::OnDisable() {
    m_currentTarget = nullptr;
}

void KillAura::OnTick() {
    auto* rangeSetting = GetSetting<FloatSetting>("Range");
    auto* cpsSetting   = GetSetting<FloatSetting>("CPS");
    if (!rangeSetting || !cpsSetting) return;
    
    // Find best target
    m_currentTarget = FindTarget();
    if (!m_currentTarget) return;
    
    // CPS timing
    float interval = 1000.0f / cpsSetting->value; // ms between attacks
    m_attackTimer += 50.0f; // ~50ms per tick
    
    if (m_attackTimer >= interval) {
        m_attackTimer = 0.0f;
        
        // Rotate if enabled
        auto* rotSetting = GetSetting<BoolSetting>("Rotation");
        if (rotSetting && rotSetting->value) {
            RotateToTarget(m_currentTarget);
        }
        
        Attack(m_currentTarget);
    }
}

void KillAura::OnRender(float delta) {
    // Render target indicator (circle around target)
    if (m_currentTarget) {
        // TODO: Draw ESP circle using ImGui
    }
}

void* KillAura::FindTarget() {
    // This would use the SDK to enumerate entities in range
    // Pattern: iterate Level::getEntities(), filter by settings
    return nullptr; // Placeholder — real impl uses SDK
}

bool KillAura::IsValidTarget(void* entity) {
    if (!entity) return false;
    
    auto* playerSetting = GetSetting<BoolSetting>("Players");
    auto* mobSetting    = GetSetting<BoolSetting>("Mobs");
    auto* animalSetting = GetSetting<BoolSetting>("Animals");
    
    // Check entity type against filter settings
    // Uses SDK::Actor::isPlayer(), isMob(), etc.
    return true; // Placeholder
}

void KillAura::RotateToTarget(void* entity) {
    // Calculate yaw/pitch to target position
    // Set player rotation via SDK
}

void KillAura::Attack(void* entity) {
    // Call GameMode::attack(entity)
    // Uses hooked function pointer
}

} // namespace Nexus
