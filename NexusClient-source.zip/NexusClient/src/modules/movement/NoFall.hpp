#pragma once
#include "../Module.hpp"

namespace Nexus {

class NoFall : public Module {
public:
    NoFall() : Module("NoFall", "Prevents fall damage",
                      Category::Movement) {
        AddMode("Mode", {"Packet", "Motion", "Flag"}, 0);
        SetColor(0.5f, 0.9f, 0.3f);
    }
    
    void OnEnable() override {}
    void OnDisable() override {}
    void OnTick() override;
    void OnPacketSend(void* packet) override;
};

} // namespace Nexus
