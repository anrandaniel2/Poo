#pragma once
#include "../Module.hpp"

namespace Nexus {

class FastPlace : public Module {
public:
    FastPlace() : Module("FastPlace", "Place blocks faster",
                         Category::Player) {
        AddFloat("Delay", 0.0f, 0.0f, 4.0f, 1.0f, "ticks",
                 "Delay between placements");
        SetColor(0.6f, 0.8f, 0.3f);
    }
    
    void OnEnable() override;
    void OnDisable() override;
    void OnTick() override;
};

} // namespace Nexus
