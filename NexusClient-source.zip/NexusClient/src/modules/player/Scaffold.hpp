#pragma once
#include "../Module.hpp"

namespace Nexus {

class Scaffold : public Module {
public:
    Scaffold() : Module("Scaffold", "Automatically places blocks under you",
                        Category::Player) {
        AddBool("Tower", true, "Place blocks vertically while jumping");
        AddBool("SafeWalk", true, "Prevent walking off edges");
        AddBool("Rotation", true, "Rotate towards block placement");
        AddFloat("Extend", 0.0f, 0.0f, 5.0f, 1.0f, "blocks",
                 "Extend reach forward");
        AddMode("Block Source", {"Inventory", "Hotbar"}, 0);
        SetColor(0.9f, 0.6f, 0.2f);
    }
    
    void OnEnable() override {}
    void OnDisable() override {}
    void OnTick() override;
    void OnPlayerTick(void* player) override;
};

} // namespace Nexus
