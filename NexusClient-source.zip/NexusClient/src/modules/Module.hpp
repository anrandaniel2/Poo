#pragma once
/**
 * Module.hpp — Base class for all client modules.
 * Provides toggle state, settings, keybinds, and category.
 */

#include <string>
#include <vector>
#include <memory>
#include <functional>
#include <variant>

namespace Nexus {

/**
 * Module setting types — stored as variants for type safety.
 */
struct BoolSetting {
    std::string name;
    std::string description;
    bool value;
    bool defaultValue;
};

struct FloatSetting {
    std::string name;
    std::string description;
    float value;
    float min, max, step;
    float defaultValue;
    std::string suffix; // e.g., "blocks", "ms"
};

struct IntSetting {
    std::string name;
    std::string description;
    int value;
    int min, max;
    int defaultValue;
};

struct ModeSetting {
    std::string name;
    std::string description;
    int selectedIndex;
    std::vector<std::string> modes;
    int defaultIndex;
};

struct KeybindSetting {
    std::string name;
    int keyCode;
    int defaultKeyCode;
};

using Setting = std::variant<BoolSetting, FloatSetting, IntSetting, 
                              ModeSetting, KeybindSetting>;

/**
 * Abstract module base class.
 */
class Module {
public:
    enum class Category {
        Combat,
        Movement,
        Render,
        Player,
        World,
        Misc
    };
    
    Module(const std::string& name, const std::string& description,
           Category category, int defaultKey = 0)
        : m_name(name), m_description(description),
          m_category(category), m_keyBind(defaultKey) {}
    
    virtual ~Module() = default;
    
    // Lifecycle
    virtual void OnEnable() {}
    virtual void OnDisable() {}
    virtual void OnTick() {}
    virtual void OnRender(float delta) {}
    virtual void OnPlayerTick(void* player) {}
    virtual void OnAttack(void* gameMode, void* entity) {}
    virtual void OnLevelTick(void* level) {}
    virtual void OnPacketSend(void* packet) {}
    virtual void OnPacketReceive(void* packet) {}
    
    // Toggle
    void Toggle() { SetEnabled(!m_enabled); }
    void SetEnabled(bool enabled) {
        if (m_enabled == enabled) return;
        m_enabled = enabled;
        if (enabled) OnEnable();
        else OnDisable();
    }
    bool IsEnabled() const { return m_enabled; }
    
    // Properties
    const std::string& GetName() const { return m_name; }
    const std::string& GetDescription() const { return m_description; }
    Category GetCategory() const { return m_category; }
    int GetKeyBind() const { return m_keyBind; }
    void SetKeyBind(int key) { m_keyBind = key; }
    
    // Settings
    std::vector<Setting>& GetSettings() { return m_settings; }
    const std::vector<Setting>& GetSettings() const { return m_settings; }
    
    // Color customization
    struct Color { float r, g, b, a; };
    void SetColor(float r, float g, float b, float a = 1.0f) {
        m_color = {r, g, b, a};
    }
    Color GetColor() const { return m_color; }
    
    // Category name helper
    static const char* CategoryName(Category cat) {
        switch (cat) {
            case Category::Combat:   return "Combat";
            case Category::Movement: return "Movement";
            case Category::Render:   return "Render";
            case Category::Player:   return "Player";
            case Category::World:    return "World";
            case Category::Misc:     return "Misc";
        }
        return "Unknown";
    }

protected:
    // Helper to add settings
    void AddBool(const std::string& name, bool defaultVal,
                 const std::string& desc = "") {
        m_settings.push_back(BoolSetting{name, desc, defaultVal, defaultVal});
    }
    
    void AddFloat(const std::string& name, float defaultVal,
                  float min, float max, float step = 0.1f,
                  const std::string& suffix = "",
                  const std::string& desc = "") {
        m_settings.push_back(FloatSetting{
            name, desc, defaultVal, min, max, step, defaultVal, suffix});
    }
    
    void AddInt(const std::string& name, int defaultVal,
                int min, int max, const std::string& desc = "") {
        m_settings.push_back(IntSetting{name, desc, defaultVal, min, max, defaultVal});
    }
    
    void AddMode(const std::string& name,
                 const std::vector<std::string>& modes, int defaultIdx = 0,
                 const std::string& desc = "") {
        m_settings.push_back(ModeSetting{name, desc, defaultIdx, modes, defaultIdx});
    }
    
    // Get setting values
    template<typename T>
    T* GetSetting(const std::string& name) {
        for (auto& s : m_settings) {
            if (auto* val = std::get_if<T>(&s)) {
                if (val->name == name) return val;
            }
        }
        return nullptr;
    }

private:
    std::string m_name;
    std::string m_description;
    Category m_category;
    int m_keyBind;
    bool m_enabled = false;
    std::vector<Setting> m_settings;
    Color m_color = {0.4f, 0.6f, 1.0f, 1.0f};
};

} // namespace Nexus
