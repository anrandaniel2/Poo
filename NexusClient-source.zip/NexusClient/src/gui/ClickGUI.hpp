#pragma once
/**
 * ClickGUI.hpp — ImGui-based module menu.
 * Features: category tabs, search, settings panels,
 * animations, custom theme with blur backgrounds.
 */

#include <string>
#include <imgui.h>

namespace Nexus {

class ClickGUI {
public:
    static ClickGUI& GetInstance() {
        static ClickGUI instance;
        return instance;
    }
    
    /**
     * Initialize ImGui context and apply custom theme.
     */
    void Init();
    
    /**
     * Render the full GUI overlay.
     */
    void Render();
    
    /**
     * Handle touch events for menu navigation.
     * Returns true if the event was consumed by the GUI.
     */
    bool HandleTouch(int action, float x, float y, int pointerId);
    
    /**
     * Toggle menu visibility.
     */
    void Toggle() { m_visible = !m_visible; }
    bool IsVisible() const { return m_visible; }
    
private:
    ClickGUI() = default;
    
    void ApplyTheme();
    void RenderCategoryTabs();
    void RenderModuleList();
    void RenderModuleSettings(class Module* module);
    void RenderSearchBar();
    void RenderHeader();
    
    bool m_visible = false;
    bool m_initialized = false;
    int m_selectedCategory = 0;
    std::string m_searchQuery;
    float m_animationProgress = 0.0f;
    
    // Module expansion state
    std::string m_expandedModule;
};

} // namespace Nexus
