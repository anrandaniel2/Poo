#pragma once
#include "../Module.hpp"

namespace Nexus {

class Zoom : public Module {
public:
    Zoom() : Module("Zoom", "Zooms in the camera view",
                    Category::Render) {
        AddFloat("FOV", 30.0f, 10.0f, 90.0f, 1.0f, "°");
        AddBool("Smooth", true, "Smooth zoom transition");
        SetColor(0.6f, 0.6f, 0.9f);
    }
    
    void OnEnable() override;
    void OnDisable() override;
    void OnTick() override;
};

} // namespace Nexus
