#pragma once
#include "../Module.hpp"

namespace Nexus {

class ESP : public Module {
public:
    ESP() : Module("ESP", "Shows player and entity information through walls",
                   Category::Render) {
        AddMode("Box", {"None", "2D", "Corner", "3D"}, 2);
        AddBool("Tracers", false, "Draw lines to entities");
        AddBool("Nametags", true, "Show entity names");
        AddBool("Health Bar", true, "Show health bars");
        AddBool("Distance", true, "Show distance to entity");
        AddBool("Chams", false, "Color entities through walls");
        AddFloat("Max Distance", 128.0f, 16.0f, 256.0f, 8.0f, "blocks");
        AddBool("Players", true);
        AddBool("Mobs", false);
        AddBool("Items", false);
        SetColor(0.2f, 0.8f, 1.0f);
    }
    
    void OnEnable() override {}
    void OnDisable() override {}
    void OnRender(float delta) override;
};

} // namespace Nexus
