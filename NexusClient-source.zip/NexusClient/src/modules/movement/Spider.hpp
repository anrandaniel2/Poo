#pragma once
#include "../Module.hpp"

namespace Nexus {

class Spider : public Module {
public:
    Spider() : Module("Spider", "Climb walls like a spider",
                      Category::Movement) {
        AddFloat("Speed", 0.2f, 0.05f, 1.0f, 0.05f, "m/s");
        AddMode("Mode", {"Vanilla", "Motion"}, 0);
        SetColor(0.5f, 0.5f, 0.5f);
    }
    
    void OnEnable() override {}
    void OnDisable() override {}
    void OnPlayerTick(void* player) override;
};

} // namespace Nexus
