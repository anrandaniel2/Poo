#pragma once
/**
 * Level.hpp — Bedrock Level/Dimension class.
 */

#include "Actor.hpp"
#include <vector>

namespace Nexus::SDK {

class Level {
public:
    // Entity enumeration
    std::vector<Actor*> getEntities();
    std::vector<Actor*> getPlayers();
    
    // Block access
    // Block* getBlock(const Vec3& pos);
    // void setBlock(const Vec3& pos, Block* block);
    
    // Time
    int getTime();
    void setTime(int time);
    
    // Weather
    float getRainLevel();
    void setRainLevel(float level);
    
    // Dimension
    int getDimensionId();
    
    // Local player
    Player* getLocalPlayer();
};

} // namespace Nexus::SDK
