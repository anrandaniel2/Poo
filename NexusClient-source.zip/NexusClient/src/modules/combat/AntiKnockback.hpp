#pragma once
#include "../Module.hpp"

namespace Nexus {

class AntiKnockback : public Module {
public:
    AntiKnockback() : Module("AntiKnockback", "Reduces or eliminates knockback",
                             Category::Combat) {
        AddFloat("Horizontal", 0.0f, 0.0f, 1.0f, 0.05f, "x",
                 "Horizontal knockback multiplier");
        AddFloat("Vertical", 0.0f, 0.0f, 1.0f, 0.05f, "x",
                 "Vertical knockback multiplier");
        AddMode("Mode", {"Cancel", "Modify"}, 0);
        SetColor(0.5f, 0.3f, 0.8f);
    }
    
    void OnEnable() override {}
    void OnDisable() override {}
    void OnPacketReceive(void* packet) override;
};

} // namespace Nexus
