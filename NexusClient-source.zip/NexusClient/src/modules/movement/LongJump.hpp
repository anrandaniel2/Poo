#pragma once
#include "../Module.hpp"

namespace Nexus {

class LongJump : public Module {
public:
    LongJump() : Module("LongJump", "Jump further than normal",
                        Category::Movement) {
        AddFloat("Boost", 1.5f, 0.5f, 5.0f, 0.1f, "x");
        AddFloat("Height", 0.42f, 0.1f, 2.0f, 0.05f, "blocks");
        AddMode("Mode", {"Vanilla", "Fireball", "NCP"}, 0);
        SetColor(0.6f, 0.8f, 0.2f);
    }
    
    void OnEnable() override {}
    void OnDisable() override {}
    void OnPlayerTick(void* player) override;
};

} // namespace Nexus
