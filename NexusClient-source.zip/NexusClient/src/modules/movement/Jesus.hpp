#pragma once
#include "../Module.hpp"

namespace Nexus {

class Jesus : public Module {
public:
    Jesus() : Module("Jesus", "Walk on water and lava",
                     Category::Movement) {
        AddMode("Mode", {"Solid", "Dolphin", "Trident"}, 0);
        AddBool("Lava", true, "Also walk on lava");
        SetColor(0.3f, 0.6f, 1.0f);
    }
    
    void OnEnable() override {}
    void OnDisable() override {}
    void OnPlayerTick(void* player) override;
};

} // namespace Nexus
