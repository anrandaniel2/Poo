#pragma once
/**
 * ObfString.hpp — Compile-time string obfuscation.
 * Prevents strings from appearing in plaintext in the binary.
 * 
 * Usage: OBF("my secret string")
 * The string is XOR-encrypted at compile time and decrypted at runtime.
 */

#include <cstdint>
#include <cstring>
#include <array>

namespace Nexus::Obf {

// Compile-time random seed from __TIME__
constexpr uint32_t TimeSeed() {
    uint32_t seed = 0;
    const char* t = __TIME__; // "HH:MM:SS"
    seed = (t[0] - '0') * 10 + (t[1] - '0');
    seed = seed * 60 + (t[3] - '0') * 10 + (t[4] - '0');
    seed = seed * 60 + (t[6] - '0') * 10 + (t[7] - '0');
    return seed;
}

// Simple LCG for compile-time pseudo-random
constexpr uint8_t RandomByte(uint32_t seed, uint32_t index) {
    uint32_t val = seed;
    for (uint32_t i = 0; i <= index; ++i)
        val = val * 1103515245 + 12345;
    return static_cast<uint8_t>((val >> 16) & 0xFF);
}

template<size_t N>
class ObfuscatedString {
public:
    constexpr ObfuscatedString(const char (&str)[N], uint32_t seed)
        : m_key(RandomByte(seed, 0)) {
        for (size_t i = 0; i < N; ++i) {
            m_data[i] = str[i] ^ (m_key + static_cast<uint8_t>(i * 3));
        }
    }
    
    /** Decrypt and return the original string */
    const char* Decrypt() const {
        // Thread-local buffer to avoid allocations
        thread_local char buffer[512];
        for (size_t i = 0; i < N && i < sizeof(buffer) - 1; ++i) {
            buffer[i] = m_data[i] ^ (m_key + static_cast<uint8_t>(i * 3));
        }
        buffer[N < sizeof(buffer) ? N - 1 : sizeof(buffer) - 1] = '\0';
        return buffer;
    }
    
    operator const char*() const { return Decrypt(); }

private:
    std::array<char, N> m_data{};
    uint8_t m_key;
};

} // namespace Nexus::Obf

// Convenience macro
#define OBF(str) (::Nexus::Obf::ObfuscatedString<sizeof(str)>(str, ::Nexus::Obf::TimeSeed()).Decrypt())
