#pragma once
#include "../Module.hpp"

namespace Nexus {

class Velocity : public Module {
public:
    Velocity() : Module("Velocity", "Controls knockback velocity",
                        Category::Combat) {
        AddFloat("Horizontal", 0.0f, -1.0f, 1.0f, 0.05f, "x");
        AddFloat("Vertical", 0.0f, -1.0f, 1.0f, 0.05f, "x");
        AddMode("Mode", {"Simple", "Reverse", "AAC"}, 0);
        SetColor(0.6f, 0.2f, 0.9f);
    }
    
    void OnEnable() override {}
    void OnDisable() override {}
    void OnTick() override;
};

} // namespace Nexus
