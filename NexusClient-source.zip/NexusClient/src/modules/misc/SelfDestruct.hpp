#pragma once
#include "../Module.hpp"

namespace Nexus {

class SelfDestruct : public Module {
public:
    SelfDestruct() : Module("SelfDestruct", "Unloads the client and removes traces",
                            Category::Misc) {
        SetColor(0.9f, 0.1f, 0.1f);
    }
    
    void OnEnable() override;
    void OnDisable() override {}
};

} // namespace Nexus
