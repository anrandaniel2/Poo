# Android ARM64 Toolchain for NexusClient
# Usage: cmake -DCMAKE_TOOLCHAIN_FILE=cmake/android-arm64.toolchain.cmake ..

# Set ANDROID_NDK_HOME if not already set
if(NOT DEFINED ENV{ANDROID_NDK_HOME})
    message(FATAL_ERROR "ANDROID_NDK_HOME environment variable not set. "
                        "Please set it to your NDK installation path.")
endif()

set(ANDROID_NDK $ENV{ANDROID_NDK_HOME})
set(CMAKE_SYSTEM_NAME Android)
set(CMAKE_SYSTEM_VERSION 26)
set(CMAKE_ANDROID_ARCH_ABI arm64-v8a)
set(CMAKE_ANDROID_NDK ${ANDROID_NDK})
set(CMAKE_ANDROID_STL_TYPE c++_shared)

# Use Clang
set(CMAKE_C_COMPILER   "${ANDROID_NDK}/toolchains/llvm/prebuilt/linux-x86_64/bin/aarch64-linux-android26-clang")
set(CMAKE_CXX_COMPILER "${ANDROID_NDK}/toolchains/llvm/prebuilt/linux-x86_64/bin/aarch64-linux-android26-clang++")

# Sysroot
set(CMAKE_SYSROOT "${ANDROID_NDK}/toolchains/llvm/prebuilt/linux-x86_64/sysroot")

# Compiler flags
set(CMAKE_CXX_FLAGS_INIT "-fPIC -fno-rtti")
set(CMAKE_C_FLAGS_INIT   "-fPIC")
