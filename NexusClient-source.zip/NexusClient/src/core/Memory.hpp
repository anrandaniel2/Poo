#pragma once
/**
 * Memory.hpp — Pattern scanner & memory utilities.
 * Uses signature scanning instead of hardcoded offsets
 * for compatibility across Bedrock versions.
 */

#include <cstdint>
#include <string>
#include <vector>
#include <optional>
#include <unordered_map>

namespace Nexus {

class Memory {
public:
    /**
     * Initialize the memory scanner with the base module.
     * Parses ELF headers to find .text section bounds.
     */
    static void Init(void* moduleHandle);
    
    /**
     * Scan for a byte pattern in libminecraftpe.so
     * Pattern format: "48 89 5C 24 ?? 57 48 83 EC 20"
     * Use ?? for wildcard bytes.
     * 
     * @param signature Space-separated hex bytes
     * @return Address of first match, or 0 if not found
     */
    static uintptr_t SigScan(const std::string& signature);
    
    /**
     * Cached signature scan — stores results to avoid rescanning.
     */
    static uintptr_t SigScanCached(const std::string& name,
                                     const std::string& signature);
    
    /**
     * Read a value from memory at the given address.
     */
    template<typename T>
    static T Read(uintptr_t address) {
        return *reinterpret_cast<T*>(address);
    }
    
    /**
     * Write a value to memory at the given address.
     * Handles page protection changes automatically.
     */
    template<typename T>
    static void Write(uintptr_t address, T value);
    
    /**
     * Write raw bytes with protection handling.
     */
    static bool WriteBytes(uintptr_t address, const std::vector<uint8_t>& bytes);
    
    /**
     * Make memory region writable.
     */
    static bool Unprotect(uintptr_t address, size_t size);
    
    /**
     * Get the base address of libminecraftpe.so
     */
    static uintptr_t GetBase() { return s_baseAddress; }
    
    /**
     * Resolve a relative address.
     */
    static uintptr_t GetAbsolute(uintptr_t offset) {
        return s_baseAddress + offset;
    }
    
    /**
     * Dereference a pointer chain:
     * [[base + offset1] + offset2] + offset3 ...
     */
    static uintptr_t DerefChain(uintptr_t base,
                                 const std::vector<uintptr_t>& offsets);

private:
    static uintptr_t s_baseAddress;
    static uintptr_t s_textStart;
    static uintptr_t s_textEnd;
    static std::unordered_map<std::string, uintptr_t> s_cache;
    
    /**
     * Parse the pattern string into bytes and mask.
     */
    static std::pair<std::vector<uint8_t>, std::vector<bool>>
    ParsePattern(const std::string& signature);
};

} // namespace Nexus
