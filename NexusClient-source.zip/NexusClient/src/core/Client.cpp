#include "Client.hpp"
#include "ObfString.hpp"

// Combat modules
#include "../modules/combat/KillAura.hpp"
#include "../modules/combat/Reach.hpp"
#include "../modules/combat/Criticals.hpp"
#include "../modules/combat/AutoClicker.hpp"
#include "../modules/combat/AntiKnockback.hpp"
#include "../modules/combat/Velocity.hpp"

// Movement modules
#include "../modules/movement/Fly.hpp"
#include "../modules/movement/Speed.hpp"
#include "../modules/movement/Sprint.hpp"
#include "../modules/movement/NoFall.hpp"
#include "../modules/movement/Jesus.hpp"
#include "../modules/movement/Step.hpp"
#include "../modules/movement/LongJump.hpp"
#include "../modules/movement/Spider.hpp"
#include "../modules/movement/Glide.hpp"

// Render modules
#include "../modules/render/ESP.hpp"
#include "../modules/render/Fullbright.hpp"
#include "../modules/render/NoHurtCam.hpp"
#include "../modules/render/Freecam.hpp"
#include "../modules/render/Nametags.hpp"
#include "../modules/render/Zoom.hpp"

// Player modules
#include "../modules/player/AutoTool.hpp"
#include "../modules/player/FastPlace.hpp"
#include "../modules/player/Scaffold.hpp"
#include "../modules/player/Nuker.hpp"
#include "../modules/player/NoSlow.hpp"
#include "../modules/player/ChestStealer.hpp"

// World modules
#include "../modules/world/XRay.hpp"
#include "../modules/world/Timer.hpp"
#include "../modules/world/Weather.hpp"

// Misc modules
#include "../modules/misc/Disabler.hpp"
#include "../modules/misc/Spammer.hpp"
#include "../modules/misc/SelfDestruct.hpp"

#include <android/log.h>
#define LOGI(...) __android_log_print(ANDROID_LOG_INFO, "NexusClient", __VA_ARGS__)

namespace Nexus {

void Client::Init() {
    LOGI(OBF("Initializing NexusClient..."));
    
    // Register all modules
    RegisterAllModules();
    
    // Load saved configuration
    m_configManager.LoadDefault();
    
    m_initialized = true;
    LOGI(OBF("Client initialized with %zu modules"), m_modules.size());
}

void Client::Shutdown() {
    LOGI(OBF("Shutting down NexusClient..."));
    
    // Disable all modules
    for (auto& mod : m_modules) {
        if (mod->IsEnabled())
            mod->SetEnabled(false);
    }
    
    // Save config
    m_configManager.SaveDefault();
    
    m_initialized = false;
}

void Client::RegisterModule(std::unique_ptr<Module> module) {
    LOGI(OBF("Registered module: %s"), module->GetName().c_str());
    m_modules.push_back(std::move(module));
}

Module* Client::GetModule(const std::string& name) {
    for (auto& mod : m_modules) {
        if (mod->GetName() == name)
            return mod.get();
    }
    return nullptr;
}

std::vector<Module*> Client::GetModulesByCategory(Module::Category cat) const {
    std::vector<Module*> result;
    for (auto& mod : m_modules) {
        if (mod->GetCategory() == cat)
            result.push_back(mod.get());
    }
    return result;
}

void Client::RegisterAllModules() {
    // Combat
    RegisterModule(std::make_unique<KillAura>());
    RegisterModule(std::make_unique<Reach>());
    RegisterModule(std::make_unique<Criticals>());
    RegisterModule(std::make_unique<AutoClicker>());
    RegisterModule(std::make_unique<AntiKnockback>());
    RegisterModule(std::make_unique<Velocity>());
    
    // Movement
    RegisterModule(std::make_unique<Fly>());
    RegisterModule(std::make_unique<Speed>());
    RegisterModule(std::make_unique<Sprint>());
    RegisterModule(std::make_unique<NoFall>());
    RegisterModule(std::make_unique<Jesus>());
    RegisterModule(std::make_unique<Step>());
    RegisterModule(std::make_unique<LongJump>());
    RegisterModule(std::make_unique<Spider>());
    RegisterModule(std::make_unique<Glide>());
    
    // Render
    RegisterModule(std::make_unique<ESP>());
    RegisterModule(std::make_unique<Fullbright>());
    RegisterModule(std::make_unique<NoHurtCam>());
    RegisterModule(std::make_unique<Freecam>());
    RegisterModule(std::make_unique<Nametags>());
    RegisterModule(std::make_unique<Zoom>());
    
    // Player
    RegisterModule(std::make_unique<AutoTool>());
    RegisterModule(std::make_unique<FastPlace>());
    RegisterModule(std::make_unique<Scaffold>());
    RegisterModule(std::make_unique<Nuker>());
    RegisterModule(std::make_unique<NoSlow>());
    RegisterModule(std::make_unique<ChestStealer>());
    
    // World
    RegisterModule(std::make_unique<XRay>());
    RegisterModule(std::make_unique<Timer>());
    RegisterModule(std::make_unique<Weather>());
    
    // Misc
    RegisterModule(std::make_unique<Disabler>());
    RegisterModule(std::make_unique<Spammer>());
    RegisterModule(std::make_unique<SelfDestruct>());
}

} // namespace Nexus
