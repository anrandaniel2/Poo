#pragma once
#include "../Module.hpp"

namespace Nexus {

class KillAura : public Module {
public:
    KillAura() : Module("KillAura", "Automatically attacks nearby entities",
                        Category::Combat) {
        AddFloat("Range", 3.5f, 1.0f, 7.0f, 0.1f, "blocks",
                 "Maximum attack range");
        AddFloat("CPS", 12.0f, 1.0f, 20.0f, 0.5f, "clicks/s",
                 "Clicks per second");
        AddMode("Target", {"Single", "Multi", "Switch"}, 0,
                "Target selection mode");
        AddMode("Priority", {"Distance", "Health", "Angle"}, 0,
                "Target priority mode");
        AddBool("Players", true, "Target players");
        AddBool("Mobs", false, "Target hostile mobs");
        AddBool("Animals", false, "Target passive mobs");
        AddBool("Rotation", true, "Rotate towards target");
        AddBool("Through Walls", false, "Attack through walls");
        SetColor(1.0f, 0.3f, 0.3f);
    }
    
    void OnEnable() override;
    void OnDisable() override;
    void OnTick() override;
    void OnRender(float delta) override;
    
private:
    void* m_currentTarget = nullptr;
    float m_attackTimer = 0.0f;
    
    void* FindTarget();
    bool IsValidTarget(void* entity);
    void RotateToTarget(void* entity);
    void Attack(void* entity);
};

} // namespace Nexus
