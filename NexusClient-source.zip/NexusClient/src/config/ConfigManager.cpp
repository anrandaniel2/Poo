#include "ConfigManager.hpp"
#include "../core/Client.hpp"
#include "../core/ObfString.hpp"

#include <fstream>
#include <sstream>
#include <chrono>
#include <android/log.h>

// Using nlohmann::json
#include <nlohmann/json.hpp>
using json = nlohmann::json;

#define LOGI(...) __android_log_print(ANDROID_LOG_INFO, "NexusConfig", __VA_ARGS__)

namespace Nexus {

void ConfigManager::Init(const std::string& basePath) {
    m_basePath = basePath.empty()
        ? std::string(OBF("/sdcard/NexusClient/configs/"))
        : basePath;
    
    // Create directory if not exists
    std::filesystem::create_directories(m_basePath);
    LOGI(OBF("Config directory: %s"), m_basePath.c_str());
}

std::string ConfigManager::GetConfigPath(const std::string& name) const {
    return m_basePath + name + ".json";
}

bool ConfigManager::Save(const std::string& name) {
    std::string content = SerializeModules();
    std::ofstream file(GetConfigPath(name));
    if (!file.is_open()) return false;
    file << content;
    file.close();
    LOGI(OBF("Saved config: %s"), name.c_str());
    return true;
}

bool ConfigManager::Load(const std::string& name) {
    std::ifstream file(GetConfigPath(name));
    if (!file.is_open()) return false;
    
    std::stringstream ss;
    ss << file.rdbuf();
    DeserializeModules(ss.str());
    
    LOGI(OBF("Loaded config: %s"), name.c_str());
    return true;
}

bool ConfigManager::Delete(const std::string& name) {
    return std::filesystem::remove(GetConfigPath(name));
}

std::vector<ConfigManager::ConfigInfo> ConfigManager::ListConfigs() const {
    std::vector<ConfigInfo> configs;
    
    if (!std::filesystem::exists(m_basePath)) return configs;
    
    for (auto& entry : std::filesystem::directory_iterator(m_basePath)) {
        if (entry.path().extension() == ".json") {
            ConfigInfo info;
            info.filename = entry.path().filename().string();
            info.name = entry.path().stem().string();
            
            auto ftime = std::filesystem::last_write_time(entry.path());
            info.timestamp = ""; // Format as needed
            
            configs.push_back(info);
        }
    }
    
    return configs;
}

void ConfigManager::SaveDefault() { Save(OBF("default")); }
void ConfigManager::LoadDefault() { Load(OBF("default")); }

std::string ConfigManager::SerializeModules() {
    json root;
    root["version"] = "1.0.0";
    root["client"] = "NexusClient";
    
    auto& client = Client::GetInstance();
    json modulesJson = json::array();
    
    for (auto& mod : client.GetModules()) {
        json modJson;
        modJson["name"] = mod->GetName();
        modJson["enabled"] = mod->IsEnabled();
        modJson["keybind"] = mod->GetKeyBind();
        modJson["color"] = {
            mod->GetColor().r, mod->GetColor().g,
            mod->GetColor().b, mod->GetColor().a
        };
        
        // Serialize settings
        json settingsJson = json::array();
        for (auto& setting : mod->GetSettings()) {
            json s;
            std::visit([&s](auto&& arg) {
                using T = std::decay_t<decltype(arg)>;
                s["name"] = arg.name;
                if constexpr (std::is_same_v<T, BoolSetting>) {
                    s["type"] = "bool";
                    s["value"] = arg.value;
                } else if constexpr (std::is_same_v<T, FloatSetting>) {
                    s["type"] = "float";
                    s["value"] = arg.value;
                } else if constexpr (std::is_same_v<T, IntSetting>) {
                    s["type"] = "int";
                    s["value"] = arg.value;
                } else if constexpr (std::is_same_v<T, ModeSetting>) {
                    s["type"] = "mode";
                    s["value"] = arg.selectedIndex;
                }
            }, setting);
            settingsJson.push_back(s);
        }
        modJson["settings"] = settingsJson;
        modulesJson.push_back(modJson);
    }
    
    root["modules"] = modulesJson;
    return root.dump(2);
}

void ConfigManager::DeserializeModules(const std::string& jsonStr) {
    try {
        json root = json::parse(jsonStr);
        auto& client = Client::GetInstance();
        
        for (auto& modJson : root["modules"]) {
            std::string name = modJson["name"];
            Module* mod = client.GetModule(name);
            if (!mod) continue;
            
            mod->SetEnabled(modJson.value("enabled", false));
            mod->SetKeyBind(modJson.value("keybind", 0));
            
            if (modJson.contains("color")) {
                auto& c = modJson["color"];
                mod->SetColor(c[0], c[1], c[2], c[3]);
            }
            
            if (modJson.contains("settings")) {
                for (auto& sJson : modJson["settings"]) {
                    std::string sName = sJson["name"];
                    std::string sType = sJson["type"];
                    
                    for (auto& setting : mod->GetSettings()) {
                        std::visit([&](auto&& arg) {
                            using T = std::decay_t<decltype(arg)>;
                            if (arg.name != sName) return;
                            if constexpr (std::is_same_v<T, BoolSetting>) {
                                if (sType == "bool") arg.value = sJson["value"];
                            } else if constexpr (std::is_same_v<T, FloatSetting>) {
                                if (sType == "float") arg.value = sJson["value"];
                            } else if constexpr (std::is_same_v<T, IntSetting>) {
                                if (sType == "int") arg.value = sJson["value"];
                            } else if constexpr (std::is_same_v<T, ModeSetting>) {
                                if (sType == "mode") arg.selectedIndex = sJson["value"];
                            }
                        }, setting);
                    }
                }
            }
        }
    } catch (const std::exception& e) {
        LOGI(OBF("Config parse error: %s"), e.what());
    }
}

std::string ConfigManager::ExportToString(const std::string& name) {
    std::ifstream file(GetConfigPath(name));
    if (!file.is_open()) return "";
    std::stringstream ss;
    ss << file.rdbuf();
    return ss.str();
}

bool ConfigManager::ImportFromString(const std::string& jsonStr,
                                      const std::string& name) {
    try {
        json::parse(jsonStr); // Validate
        std::ofstream file(GetConfigPath(name));
        if (!file.is_open()) return false;
        file << jsonStr;
        return true;
    } catch (...) {
        return false;
    }
}

} // namespace Nexus
