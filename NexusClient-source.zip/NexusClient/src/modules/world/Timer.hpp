#pragma once
#include "../Module.hpp"

namespace Nexus {

class Timer : public Module {
public:
    Timer() : Module("Timer", "Changes game tick speed",
                     Category::World) {
        AddFloat("Speed", 2.0f, 0.1f, 10.0f, 0.1f, "x",
                 "Game speed multiplier");
        SetColor(0.9f, 0.7f, 0.2f);
    }
    
    void OnEnable() override;
    void OnDisable() override;
    void OnTick() override;
};

} // namespace Nexus
