#pragma once
#include "../Module.hpp"

namespace Nexus {

class Nuker : public Module {
public:
    Nuker() : Module("Nuker", "Break blocks in a radius",
                     Category::Player) {
        AddFloat("Radius", 3.0f, 1.0f, 8.0f, 0.5f, "blocks");
        AddMode("Mode", {"All", "Selected", "Ores"}, 0);
        AddBool("Flatten", false, "Only break blocks at your level");
        SetColor(0.9f, 0.3f, 0.2f);
    }
    
    void OnEnable() override {}
    void OnDisable() override {}
    void OnTick() override;
};

} // namespace Nexus
