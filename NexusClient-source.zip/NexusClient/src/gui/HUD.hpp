#pragma once
/**
 * HUD.hpp — In-game heads-up display.
 * Shows enabled modules, coordinates, FPS, etc.
 * Supports draggable elements.
 */

#include <imgui.h>
#include <string>
#include <vector>

namespace Nexus {

class HUD {
public:
    static HUD& GetInstance() {
        static HUD instance;
        return instance;
    }
    
    void Render();
    
    struct Element {
        std::string name;
        ImVec2 position;
        bool visible;
        bool dragging;
    };
    
private:
    HUD() = default;
    
    void RenderArrayList();
    void RenderCoordinates();
    void RenderFPS();
    void RenderWatermark();
    
    std::vector<Element> m_elements;
    bool m_editMode = false;
};

} // namespace Nexus
