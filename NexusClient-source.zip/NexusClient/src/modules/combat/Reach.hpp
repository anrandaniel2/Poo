#pragma once
#include "../Module.hpp"

namespace Nexus {

class Reach : public Module {
public:
    Reach() : Module("Reach", "Extends attack reach distance",
                     Category::Combat) {
        AddFloat("Distance", 4.0f, 3.0f, 7.0f, 0.1f, "blocks");
        SetColor(1.0f, 0.5f, 0.2f);
    }
    
    void OnEnable() override;
    void OnDisable() override;
    void OnTick() override;
};

} // namespace Nexus
