#pragma once
#include "../Module.hpp"

namespace Nexus {

class ChestStealer : public Module {
public:
    ChestStealer() : Module("ChestStealer", "Automatically takes items from chests",
                            Category::Player) {
        AddFloat("Delay", 50.0f, 0.0f, 500.0f, 10.0f, "ms",
                 "Delay between each item steal");
        AddBool("Close After", true, "Close chest when done");
        AddBool("Only Valuables", false);
        SetColor(0.8f, 0.6f, 0.2f);
    }
    
    void OnEnable() override {}
    void OnDisable() override {}
    void OnTick() override;
};

} // namespace Nexus
