#pragma once
/**
 * ConfigManager.hpp — JSON-based configuration system.
 * Saves/loads module states and settings.
 */

#include <string>
#include <vector>
#include <filesystem>

namespace Nexus {

class ConfigManager {
public:
    struct ConfigInfo {
        std::string name;
        std::string filename;
        std::string timestamp;
    };
    
    /**
     * Initialize config directory.
     * Default: /sdcard/NexusClient/configs/
     */
    void Init(const std::string& basePath = "");
    
    /**
     * Save current module state to a named config.
     */
    bool Save(const std::string& name);
    
    /**
     * Load a named config and apply to modules.
     */
    bool Load(const std::string& name);
    
    /**
     * Delete a config file.
     */
    bool Delete(const std::string& name);
    
    /**
     * List all available configs.
     */
    std::vector<ConfigInfo> ListConfigs() const;
    
    /**
     * Save/load the default config (auto-saved on exit).
     */
    void SaveDefault();
    void LoadDefault();
    
    /**
     * Export config as shareable JSON string.
     */
    std::string ExportToString(const std::string& name);
    
    /**
     * Import config from JSON string.
     */
    bool ImportFromString(const std::string& json, const std::string& name);
    
private:
    std::string m_basePath;
    
    std::string GetConfigPath(const std::string& name) const;
    std::string SerializeModules();
    void DeserializeModules(const std::string& json);
};

} // namespace Nexus
