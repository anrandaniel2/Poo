#pragma once
/**
 * Hooks.hpp — Hook management using Dobby inline hooking.
 * Hooks into Bedrock's render pipeline, input, and game logic
 * to inject NexusClient functionality.
 */

#include <cstdint>
#include <functional>
#include <string>
#include <unordered_map>

// Dobby hooking framework
#include <dobby.h>

namespace Nexus {

/**
 * Typed hook wrapper — handles original function backup.
 */
template<typename FuncType>
class Hook {
public:
    using OriginalFunc = FuncType;
    
    bool Install(uintptr_t target, void* replacement) {
        m_target = target;
        int result = DobbyHook(
            reinterpret_cast<void*>(target),
            replacement,
            reinterpret_cast<void**>(&m_original)
        );
        m_installed = (result == 0);
        return m_installed;
    }
    
    void Remove() {
        if (m_installed) {
            DobbyDestroy(reinterpret_cast<void*>(m_target));
            m_installed = false;
        }
    }
    
    OriginalFunc GetOriginal() const { return m_original; }
    bool IsInstalled() const { return m_installed; }

private:
    uintptr_t m_target = 0;
    OriginalFunc m_original = nullptr;
    bool m_installed = false;
};

/**
 * Central hook manager — installs and tracks all hooks.
 */
class Hooks {
public:
    /**
     * Install all necessary hooks:
     *  - MinecraftGame::update (game tick)
     *  - ScreenView::render (ImGui overlay)
     *  - GameMode::attack (combat hooks)
     *  - Player::tick (movement hooks)
     *  - AppPlatform::handleTouch (input)
     *  - Level::tick (world hooks)
     */
    static void InstallAll();
    
    /**
     * Remove all hooks cleanly.
     */
    static void RemoveAll();
    
    // Signature patterns for Bedrock 1.20+
    struct Signatures {
        // Render hook — inject ImGui here
        static constexpr const char* ScreenView_render =
            "FF 03 05 D1 FD 7B 0F A9 F4 4F 0E A9 F6 57 0D A9";
        
        // Game tick — module updates
        static constexpr const char* MinecraftGame_update =
            "FF 43 03 D1 FD 7B 0C A9 F4 4F 0B A9 F6 57 0A A9";
        
        // Player tick — movement modifications
        static constexpr const char* Player_tick =
            "FF 83 02 D1 FD 7B 08 A9 F4 4F 07 A9 F6 57 06 A9";
            
        // Attack — combat modifications
        static constexpr const char* GameMode_attack =
            "F8 5F BC A9 F6 57 01 A9 FD 7B 02 A9 FD 83 00 91";
        
        // Touch input
        static constexpr const char* AppPlatform_handleTouch =
            "FF C3 01 D1 FD 7B 06 A9 F4 4F 05 A9 F6 57 04 A9";
        
        // Level tick
        static constexpr const char* Level_tick =
            "FF 43 04 D1 FD 7B 0E A9 F4 4F 0D A9 F6 57 0C A9";
    };
    
    // Hook instances (accessible for original calls)
    static inline Hook<void(*)(void*, void*)> hk_ScreenView_render;
    static inline Hook<void(*)(void*)> hk_MinecraftGame_update;
    static inline Hook<void(*)(void*)> hk_Player_tick;
    static inline Hook<void(*)(void*, void*)> hk_GameMode_attack;
    static inline Hook<bool(*)(void*, int, float, float, int)> hk_handleTouch;
    static inline Hook<void(*)(void*)> hk_Level_tick;
};

} // namespace Nexus
