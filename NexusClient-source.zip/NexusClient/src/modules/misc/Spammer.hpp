#pragma once
#include "../Module.hpp"

namespace Nexus {

class Spammer : public Module {
public:
    Spammer() : Module("Spammer", "Automatically sends chat messages",
                       Category::Misc) {
        AddFloat("Delay", 3000.0f, 500.0f, 10000.0f, 100.0f, "ms");
        AddBool("Randomize", true, "Add random suffix");
        SetColor(0.6f, 0.6f, 0.2f);
    }
    
    void OnEnable() override {}
    void OnDisable() override {}
    void OnTick() override;
};

} // namespace Nexus
