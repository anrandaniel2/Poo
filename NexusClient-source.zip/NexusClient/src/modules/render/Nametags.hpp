#pragma once
#include "../Module.hpp"

namespace Nexus {

class Nametags : public Module {
public:
    Nametags() : Module("Nametags", "Enhanced nametag rendering",
                        Category::Render) {
        AddFloat("Scale", 1.5f, 0.5f, 3.0f, 0.1f, "x");
        AddBool("Show Health", true);
        AddBool("Show Distance", true);
        AddBool("Background", true);
        SetColor(0.9f, 0.9f, 0.3f);
    }
    
    void OnEnable() override {}
    void OnDisable() override {}
    void OnRender(float delta) override;
};

} // namespace Nexus
