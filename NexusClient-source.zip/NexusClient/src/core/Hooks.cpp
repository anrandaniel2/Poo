#include "Hooks.hpp"
#include "Client.hpp"
#include "Memory.hpp"
#include "ObfString.hpp"
#include "../gui/ClickGUI.hpp"
#include "../gui/HUD.hpp"

#include <android/log.h>
#define LOGI(...) __android_log_print(ANDROID_LOG_INFO, "NexusHooks", __VA_ARGS__)

namespace Nexus {

// ── Hook Callbacks ──────────────────────────────────────────

/**
 * ScreenView::render hook — injects ImGui rendering.
 */
void hk_ScreenViewRender(void* _this, void* ctx) {
    // Call original render first
    Hooks::hk_ScreenView_render.GetOriginal()(_this, ctx);
    
    // Render our overlay
    if (Client::GetInstance().IsInitialized()) {
        ClickGUI::GetInstance().Render();
        HUD::GetInstance().Render();
    }
}

/**
 * MinecraftGame::update hook — per-tick module updates.
 */
void hk_MinecraftGameUpdate(void* _this) {
    Hooks::hk_MinecraftGame_update.GetOriginal()(_this);
    
    auto& client = Client::GetInstance();
    if (!client.IsInitialized()) return;
    
    // Dispatch tick event to all enabled modules
    for (auto& mod : client.GetModules()) {
        if (mod->IsEnabled()) {
            mod->OnTick();
        }
    }
}

/**
 * Player::tick hook — movement module processing.
 */
void hk_PlayerTick(void* _this) {
    auto& client = Client::GetInstance();
    
    // Pre-tick: let modules modify state
    if (client.IsInitialized()) {
        for (auto& mod : client.GetModules()) {
            if (mod->IsEnabled()) {
                mod->OnPlayerTick(_this);
            }
        }
    }
    
    Hooks::hk_Player_tick.GetOriginal()(_this);
}

/**
 * GameMode::attack hook — combat module processing.
 */
void hk_GameModeAttack(void* _this, void* entity) {
    auto& client = Client::GetInstance();
    
    if (client.IsInitialized()) {
        for (auto& mod : client.GetModules()) {
            if (mod->IsEnabled()) {
                mod->OnAttack(_this, entity);
            }
        }
    }
    
    Hooks::hk_GameMode_attack.GetOriginal()(_this, entity);
}

/**
 * Touch input hook — menu navigation.
 */
bool hk_HandleTouch(void* _this, int action, float x, float y, int pointerId) {
    // Let ClickGUI consume touch if menu is open
    if (Client::GetInstance().IsInitialized()) {
        if (ClickGUI::GetInstance().HandleTouch(action, x, y, pointerId)) {
            return true; // consumed
        }
    }
    
    return Hooks::hk_handleTouch.GetOriginal()(_this, action, x, y, pointerId);
}

/**
 * Level::tick hook — world module processing.
 */
void hk_LevelTick(void* _this) {
    auto& client = Client::GetInstance();
    
    if (client.IsInitialized()) {
        for (auto& mod : client.GetModules()) {
            if (mod->IsEnabled()) {
                mod->OnLevelTick(_this);
            }
        }
    }
    
    Hooks::hk_Level_tick.GetOriginal()(_this);
}

// ── Hook Installation ───────────────────────────────────────

void Hooks::InstallAll() {
    LOGI(OBF("Installing hooks..."));
    
    // Find functions via pattern scan
    auto addr_render = Memory::SigScanCached(
        OBF("ScreenView::render"), Signatures::ScreenView_render);
    auto addr_update = Memory::SigScanCached(
        OBF("MinecraftGame::update"), Signatures::MinecraftGame_update);
    auto addr_ptick  = Memory::SigScanCached(
        OBF("Player::tick"), Signatures::Player_tick);
    auto addr_attack = Memory::SigScanCached(
        OBF("GameMode::attack"), Signatures::GameMode_attack);
    auto addr_touch  = Memory::SigScanCached(
        OBF("handleTouch"), Signatures::AppPlatform_handleTouch);
    auto addr_ltick  = Memory::SigScanCached(
        OBF("Level::tick"), Signatures::Level_tick);
    
    // Install hooks
    if (addr_render)
        hk_ScreenView_render.Install(addr_render, (void*)hk_ScreenViewRender);
    if (addr_update)
        hk_MinecraftGame_update.Install(addr_update, (void*)hk_MinecraftGameUpdate);
    if (addr_ptick)
        hk_Player_tick.Install(addr_ptick, (void*)hk_PlayerTick);
    if (addr_attack)
        hk_GameMode_attack.Install(addr_attack, (void*)hk_GameModeAttack);
    if (addr_touch)
        hk_handleTouch.Install(addr_touch, (void*)hk_HandleTouch);
    if (addr_ltick)
        hk_Level_tick.Install(addr_ltick, (void*)hk_LevelTick);
    
    LOGI(OBF("Hooks installed: render=%d update=%d player=%d attack=%d touch=%d level=%d"),
         hk_ScreenView_render.IsInstalled(),
         hk_MinecraftGame_update.IsInstalled(),
         hk_Player_tick.IsInstalled(),
         hk_GameMode_attack.IsInstalled(),
         hk_handleTouch.IsInstalled(),
         hk_Level_tick.IsInstalled());
}

void Hooks::RemoveAll() {
    hk_ScreenView_render.Remove();
    hk_MinecraftGame_update.Remove();
    hk_Player_tick.Remove();
    hk_GameMode_attack.Remove();
    hk_handleTouch.Remove();
    hk_Level_tick.Remove();
    
    LOGI(OBF("All hooks removed"));
}

} // namespace Nexus
