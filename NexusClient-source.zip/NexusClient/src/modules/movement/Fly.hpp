#pragma once
#include "../Module.hpp"

namespace Nexus {

class Fly : public Module {
public:
    Fly() : Module("Fly", "Allows free flight through the air",
                   Category::Movement) {
        AddFloat("Speed", 2.0f, 0.5f, 10.0f, 0.1f, "m/s");
        AddMode("Mode", {"Vanilla", "Motion", "Glide", "Creative"}, 0);
        AddBool("Anti-Kick", true, "Prevents fly kick");
        AddBool("Bob", false, "Camera bobbing while flying");
        SetColor(0.3f, 0.7f, 1.0f);
    }
    
    void OnEnable() override;
    void OnDisable() override;
    void OnTick() override;
    void OnPlayerTick(void* player) override;
};

} // namespace Nexus
