#pragma once
/**
 * GameMode.hpp — Bedrock GameMode class.
 * Handles player interactions with the world.
 */

#include "Actor.hpp"

namespace Nexus::SDK {

class GameMode {
public:
    // Combat
    void attack(Actor* target);
    
    // Block interaction
    bool buildBlock(const Vec3& pos, int face);
    bool destroyBlock(const Vec3& pos, int face);
    
    // Item usage
    bool useItem();
    bool useItemOn(const Vec3& pos, int face);
    
    // Player reference
    Player* getPlayer();
};

} // namespace Nexus::SDK
