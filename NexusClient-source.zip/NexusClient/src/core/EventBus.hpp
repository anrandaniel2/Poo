#pragma once
/**
 * EventBus.hpp — Lightweight event system for module communication.
 * Supports typed events with priority ordering.
 */

#include <functional>
#include <vector>
#include <unordered_map>
#include <typeindex>
#include <algorithm>
#include <any>
#include <memory>

namespace Nexus {

// Base event class
struct Event {
    bool cancelled = false;
    virtual ~Event() = default;
};

// Specific events
struct TickEvent : Event {};

struct RenderEvent : Event {
    float deltaTime = 0.0f;
};

struct AttackEvent : Event {
    void* attacker = nullptr;
    void* target = nullptr;
};

struct MoveEvent : Event {
    float x = 0, y = 0, z = 0;
    bool onGround = false;
};

struct PacketEvent : Event {
    void* packet = nullptr;
    bool outbound = true;
};

struct KeyEvent : Event {
    int keyCode = 0;
    bool down = false;
};

class EventBus {
public:
    template<typename E>
    using Handler = std::function<void(E&)>;
    
    struct HandlerEntry {
        std::any handler;
        int priority;
    };
    
    template<typename E>
    void Subscribe(Handler<E> handler, int priority = 0) {
        auto& handlers = m_handlers[std::type_index(typeid(E))];
        handlers.push_back({handler, priority});
        std::sort(handlers.begin(), handlers.end(),
                  [](const auto& a, const auto& b) {
                      return a.priority > b.priority;
                  });
    }
    
    template<typename E>
    void Emit(E& event) {
        auto it = m_handlers.find(std::type_index(typeid(E)));
        if (it == m_handlers.end()) return;
        
        for (auto& entry : it->second) {
            if (event.cancelled) break;
            auto& fn = std::any_cast<Handler<E>&>(entry.handler);
            fn(event);
        }
    }
    
private:
    std::unordered_map<std::type_index, std::vector<HandlerEntry>> m_handlers;
};

} // namespace Nexus
