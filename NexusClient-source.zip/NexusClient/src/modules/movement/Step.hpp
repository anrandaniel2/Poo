#pragma once
#include "../Module.hpp"

namespace Nexus {

class Step : public Module {
public:
    Step() : Module("Step", "Step up blocks instantly",
                    Category::Movement) {
        AddFloat("Height", 1.0f, 0.5f, 4.0f, 0.5f, "blocks");
        AddMode("Mode", {"Vanilla", "Motion", "NCP"}, 0);
        SetColor(0.4f, 0.7f, 0.3f);
    }
    
    void OnEnable() override {}
    void OnDisable() override {}
    void OnPlayerTick(void* player) override;
};

} // namespace Nexus
