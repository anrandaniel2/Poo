#pragma once
#include "../Module.hpp"

namespace Nexus {

class NoSlow : public Module {
public:
    NoSlow() : Module("NoSlow", "Removes item usage slowdown",
                      Category::Player) {
        AddBool("Sword", true);
        AddBool("Shield", true);
        AddBool("Bow", true);
        AddBool("Food", true);
        AddFloat("Multiplier", 1.0f, 0.5f, 1.0f, 0.05f, "x");
        SetColor(0.4f, 0.7f, 0.6f);
    }
    
    void OnEnable() override;
    void OnDisable() override;
    void OnPlayerTick(void* player) override;
};

} // namespace Nexus
