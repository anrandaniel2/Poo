#pragma once
/**
 * Player.hpp — Bedrock Player class.
 * Extends Actor with player-specific functionality.
 */

#include "Actor.hpp"

namespace Nexus::SDK {

class Player : public Actor {
public:
    // Inventory
    // void* getSupplies();  // PlayerInventory
    int getSelectedSlot();
    void setSelectedSlot(int slot);
    
    // GameMode
    void* getGameMode();
    int getGameType(); // 0=survival, 1=creative, 2=adventure
    
    // Movement
    float getMovementSpeed();
    void setMovementSpeed(float speed);
    bool isSprinting();
    void setSprinting(bool sprint);
    bool isSneaking();
    bool isFlying();
    void setFlying(bool fly);
    
    // Abilities
    bool canFly();
    void setCanFly(bool can);
    float getFlySpeed();
    void setFlySpeed(float speed);
    
    // Step height
    float getStepHeight();
    void setStepHeight(float height);
    
    // Swing
    void swing();
    
    // Network
    void sendPacket(void* packet);
};

} // namespace Nexus::SDK
