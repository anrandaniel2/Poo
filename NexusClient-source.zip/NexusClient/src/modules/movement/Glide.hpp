#pragma once
#include "../Module.hpp"

namespace Nexus {

class Glide : public Module {
public:
    Glide() : Module("Glide", "Slowly glide downwards",
                     Category::Movement) {
        AddFloat("Speed", 0.1f, 0.01f, 0.5f, 0.01f, "m/s");
        AddBool("Sprint Boost", true);
        SetColor(0.7f, 0.8f, 0.9f);
    }
    
    void OnEnable() override {}
    void OnDisable() override {}
    void OnPlayerTick(void* player) override;
};

} // namespace Nexus
