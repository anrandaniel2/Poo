#pragma once
#include "../Module.hpp"

namespace Nexus {

class Freecam : public Module {
public:
    Freecam() : Module("Freecam", "Detach camera and fly around freely",
                       Category::Render) {
        AddFloat("Speed", 2.0f, 0.5f, 10.0f, 0.1f, "m/s");
        SetColor(0.5f, 0.8f, 0.9f);
    }
    
    void OnEnable() override;
    void OnDisable() override;
    void OnTick() override;
};

} // namespace Nexus
