#include "ClickGUI.hpp"
#include "../core/Client.hpp"
#include "../modules/Module.hpp"

#include <imgui.h>
#include <backends/imgui_impl_opengl3.h>
#include <cmath>
#include <algorithm>

namespace Nexus {

void ClickGUI::ApplyTheme() {
    ImGuiStyle& style = ImGui::GetStyle();
    
    // Rounded corners
    style.WindowRounding    = 12.0f;
    style.FrameRounding     = 8.0f;
    style.GrabRounding      = 6.0f;
    style.TabRounding       = 8.0f;
    style.ScrollbarRounding = 8.0f;
    style.PopupRounding     = 8.0f;
    style.ChildRounding     = 8.0f;
    
    // Padding
    style.WindowPadding  = ImVec2(16, 16);
    style.FramePadding   = ImVec2(12, 8);
    style.ItemSpacing    = ImVec2(8, 6);
    style.ItemInnerSpacing = ImVec2(8, 4);
    style.ScrollbarSize  = 12.0f;
    
    // Colors - Dark theme with accent colors
    auto& colors = style.Colors;
    colors[ImGuiCol_WindowBg]        = ImVec4(0.08f, 0.08f, 0.12f, 0.95f);
    colors[ImGuiCol_ChildBg]         = ImVec4(0.10f, 0.10f, 0.14f, 0.90f);
    colors[ImGuiCol_Border]          = ImVec4(0.20f, 0.20f, 0.30f, 0.50f);
    colors[ImGuiCol_FrameBg]         = ImVec4(0.12f, 0.12f, 0.18f, 1.00f);
    colors[ImGuiCol_FrameBgHovered]  = ImVec4(0.18f, 0.18f, 0.25f, 1.00f);
    colors[ImGuiCol_FrameBgActive]   = ImVec4(0.22f, 0.22f, 0.30f, 1.00f);
    
    // Accent: Cyan/Blue
    colors[ImGuiCol_Header]          = ImVec4(0.15f, 0.35f, 0.55f, 0.80f);
    colors[ImGuiCol_HeaderHovered]   = ImVec4(0.20f, 0.45f, 0.65f, 0.90f);
    colors[ImGuiCol_HeaderActive]    = ImVec4(0.25f, 0.50f, 0.70f, 1.00f);
    
    colors[ImGuiCol_Button]          = ImVec4(0.15f, 0.35f, 0.55f, 0.80f);
    colors[ImGuiCol_ButtonHovered]   = ImVec4(0.20f, 0.45f, 0.65f, 0.90f);
    colors[ImGuiCol_ButtonActive]    = ImVec4(0.25f, 0.50f, 0.70f, 1.00f);
    
    colors[ImGuiCol_SliderGrab]      = ImVec4(0.30f, 0.60f, 0.90f, 1.00f);
    colors[ImGuiCol_SliderGrabActive]= ImVec4(0.40f, 0.70f, 1.00f, 1.00f);
    
    colors[ImGuiCol_CheckMark]       = ImVec4(0.30f, 0.80f, 0.60f, 1.00f);
    
    colors[ImGuiCol_Tab]             = ImVec4(0.12f, 0.12f, 0.18f, 1.00f);
    colors[ImGuiCol_TabHovered]      = ImVec4(0.20f, 0.45f, 0.65f, 0.90f);
    colors[ImGuiCol_TabActive]       = ImVec4(0.15f, 0.35f, 0.55f, 1.00f);
    
    colors[ImGuiCol_Text]            = ImVec4(0.95f, 0.95f, 0.98f, 1.00f);
    colors[ImGuiCol_TextDisabled]    = ImVec4(0.45f, 0.45f, 0.55f, 1.00f);
}

void ClickGUI::Init() {
    if (m_initialized) return;
    
    // Create ImGui context
    IMGUI_CHECKVERSION();
    ImGui::CreateContext();
    
    // Apply theme
    ApplyTheme();
    
    // Initialize OpenGL ES backend
    ImGui_ImplOpenGL3_Init("#version 300 es");
    
    m_initialized = true;
}

void ClickGUI::Render() {
    if (!m_visible || !m_initialized) return;
    
    // Start frame
    ImGui_ImplOpenGL3_NewFrame();
    ImGui::NewFrame();
    
    // Animation
    m_animationProgress = std::min(m_animationProgress + 0.08f, 1.0f);
    float alpha = m_animationProgress;
    
    ImGui::SetNextWindowSize(ImVec2(600, 500), ImGuiCond_FirstUseEver);
    ImGui::SetNextWindowBgAlpha(0.95f * alpha);
    
    ImGuiWindowFlags flags = ImGuiWindowFlags_NoCollapse |
                              ImGuiWindowFlags_NoScrollbar;
    
    if (ImGui::Begin("NexusClient v1.0", &m_visible, flags)) {
        RenderHeader();
        RenderSearchBar();
        
        ImGui::Separator();
        
        // Category tabs
        RenderCategoryTabs();
        
        ImGui::SameLine();
        
        // Module list
        ImGui::BeginChild("Modules", ImVec2(0, 0), true);
        RenderModuleList();
        ImGui::EndChild();
    }
    ImGui::End();
    
    // Render
    ImGui::Render();
    ImGui_ImplOpenGL3_RenderDrawData(ImGui::GetDrawData());
}

void ClickGUI::RenderHeader() {
    ImGui::PushFont(nullptr); // Would use custom font
    ImGui::TextColored(ImVec4(0.3f, 0.7f, 1.0f, 1.0f), "NEXUS");
    ImGui::SameLine();
    ImGui::TextColored(ImVec4(0.7f, 0.7f, 0.8f, 1.0f), "CLIENT");
    ImGui::SameLine(ImGui::GetWindowWidth() - 100);
    ImGui::TextDisabled("v1.0.0");
    ImGui::PopFont();
}

void ClickGUI::RenderSearchBar() {
    char searchBuf[128] = {};
    strncpy(searchBuf, m_searchQuery.c_str(), sizeof(searchBuf) - 1);
    
    ImGui::PushItemWidth(-1);
    if (ImGui::InputTextWithHint("##search", "Search modules...",
                                  searchBuf, sizeof(searchBuf))) {
        m_searchQuery = searchBuf;
    }
    ImGui::PopItemWidth();
}

void ClickGUI::RenderCategoryTabs() {
    const char* categories[] = {
        "Combat", "Movement", "Render", "Player", "World", "Misc"
    };
    const char* icons[] = {
        "⚔", "🏃", "👁", "🧑", "🌍", "⚙"
    };
    
    ImGui::BeginChild("Categories", ImVec2(120, 0), true);
    for (int i = 0; i < 6; ++i) {
        bool selected = (m_selectedCategory == i);
        
        if (selected) {
            ImGui::PushStyleColor(ImGuiCol_Button,
                ImVec4(0.15f, 0.35f, 0.55f, 1.0f));
        }
        
        std::string label = std::string(icons[i]) + " " + categories[i];
        if (ImGui::Button(label.c_str(), ImVec2(-1, 40))) {
            m_selectedCategory = i;
        }
        
        if (selected) {
            ImGui::PopStyleColor();
        }
    }
    ImGui::EndChild();
}

void ClickGUI::RenderModuleList() {
    auto& client = Client::GetInstance();
    auto category = static_cast<Module::Category>(m_selectedCategory);
    auto modules = client.GetModulesByCategory(category);
    
    for (auto* mod : modules) {
        // Search filter
        if (!m_searchQuery.empty()) {
            std::string name = mod->GetName();
            std::string query = m_searchQuery;
            std::transform(name.begin(), name.end(), name.begin(), ::tolower);
            std::transform(query.begin(), query.end(), query.begin(), ::tolower);
            if (name.find(query) == std::string::npos) continue;
        }
        
        ImGui::PushID(mod->GetName().c_str());
        
        // Module toggle button
        auto color = mod->GetColor();
        bool enabled = mod->IsEnabled();
        
        if (enabled) {
            ImGui::PushStyleColor(ImGuiCol_Header,
                ImVec4(color.r * 0.5f, color.g * 0.5f, color.b * 0.5f, 0.8f));
        }
        
        bool expanded = (m_expandedModule == mod->GetName());
        if (ImGui::CollapsingHeader(mod->GetName().c_str(),
                                     expanded ? ImGuiTreeNodeFlags_DefaultOpen : 0)) {
            m_expandedModule = mod->GetName();
            
            // Toggle
            bool toggleState = mod->IsEnabled();
            if (ImGui::Checkbox("Enabled", &toggleState)) {
                mod->SetEnabled(toggleState);
            }
            
            ImGui::SameLine();
            ImGui::TextDisabled("%s", mod->GetDescription().c_str());
            
            // Settings
            RenderModuleSettings(mod);
        }
        
        if (enabled) {
            ImGui::PopStyleColor();
        }
        
        ImGui::PopID();
    }
}

void ClickGUI::RenderModuleSettings(Module* module) {
    for (auto& setting : module->GetSettings()) {
        std::visit([](auto&& arg) {
            using T = std::decay_t<decltype(arg)>;
            
            if constexpr (std::is_same_v<T, BoolSetting>) {
                ImGui::Checkbox(arg.name.c_str(), &arg.value);
                if (!arg.description.empty()) {
                    ImGui::SameLine();
                    ImGui::TextDisabled("(?)");
                    if (ImGui::IsItemHovered())
                        ImGui::SetTooltip("%s", arg.description.c_str());
                }
            }
            else if constexpr (std::is_same_v<T, FloatSetting>) {
                std::string format = "%.1f";
                if (!arg.suffix.empty())
                    format += " " + arg.suffix;
                ImGui::SliderFloat(arg.name.c_str(), &arg.value,
                                    arg.min, arg.max, format.c_str());
            }
            else if constexpr (std::is_same_v<T, IntSetting>) {
                ImGui::SliderInt(arg.name.c_str(), &arg.value,
                                  arg.min, arg.max);
            }
            else if constexpr (std::is_same_v<T, ModeSetting>) {
                if (ImGui::BeginCombo(arg.name.c_str(),
                                       arg.modes[arg.selectedIndex].c_str())) {
                    for (int i = 0; i < (int)arg.modes.size(); ++i) {
                        bool sel = (arg.selectedIndex == i);
                        if (ImGui::Selectable(arg.modes[i].c_str(), sel))
                            arg.selectedIndex = i;
                        if (sel) ImGui::SetItemDefaultFocus();
                    }
                    ImGui::EndCombo();
                }
            }
        }, setting);
    }
    
    // Color picker
    float col[4] = {
        module->GetColor().r, module->GetColor().g,
        module->GetColor().b, module->GetColor().a
    };
    if (ImGui::ColorEdit4("Module Color", col,
                           ImGuiColorEditFlags_NoInputs |
                           ImGuiColorEditFlags_AlphaBar)) {
        module->SetColor(col[0], col[1], col[2], col[3]);
    }
    
    // Keybind
    int key = module->GetKeyBind();
    if (ImGui::InputInt("Keybind", &key)) {
        module->SetKeyBind(key);
    }
}

bool ClickGUI::HandleTouch(int action, float x, float y, int pointerId) {
    if (!m_visible) return false;
    
    ImGuiIO& io = ImGui::GetIO();
    
    switch (action) {
        case 0: // ACTION_DOWN
            io.AddMousePosEvent(x, y);
            io.AddMouseButtonEvent(0, true);
            break;
        case 1: // ACTION_UP
            io.AddMouseButtonEvent(0, false);
            break;
        case 2: // ACTION_MOVE
            io.AddMousePosEvent(x, y);
            break;
    }
    
    return io.WantCaptureMouse;
}

} // namespace Nexus
