#pragma once
#include "../Module.hpp"

namespace Nexus {

class AutoTool : public Module {
public:
    AutoTool() : Module("AutoTool", "Automatically selects the best tool",
                        Category::Player) {
        AddBool("Sword on Attack", true);
        AddBool("Switch Back", true);
        SetColor(0.7f, 0.5f, 0.3f);
    }
    
    void OnEnable() override {}
    void OnDisable() override {}
    void OnAttack(void* gameMode, void* entity) override;
};

} // namespace Nexus
