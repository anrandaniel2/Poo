#pragma once
#include "../Module.hpp"

namespace Nexus {

class AutoClicker : public Module {
public:
    AutoClicker() : Module("AutoClicker", "Automatically clicks at set intervals",
                           Category::Combat) {
        AddFloat("Min CPS", 8.0f, 1.0f, 20.0f, 0.5f, "cps");
        AddFloat("Max CPS", 14.0f, 1.0f, 20.0f, 0.5f, "cps");
        AddBool("Right Click", false);
        AddBool("Randomize", true, "Randomize CPS within range");
        SetColor(0.9f, 0.4f, 0.4f);
    }
    
    void OnEnable() override {}
    void OnDisable() override {}
    void OnTick() override;
};

} // namespace Nexus
