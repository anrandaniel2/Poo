#pragma once
#include "../Module.hpp"

namespace Nexus {

class Disabler : public Module {
public:
    Disabler() : Module("Disabler", "Attempts to disable server anti-cheat",
                        Category::Misc) {
        AddMode("Mode", {"Generic", "Custom"}, 0);
        SetColor(0.8f, 0.2f, 0.2f);
    }
    
    void OnEnable() override;
    void OnDisable() override;
    void OnPacketSend(void* packet) override;
};

} // namespace Nexus
