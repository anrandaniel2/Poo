#pragma once
#include "../Module.hpp"

namespace Nexus {

class Speed : public Module {
public:
    Speed() : Module("Speed", "Increases movement speed",
                     Category::Movement) {
        AddFloat("Ground Speed", 1.5f, 1.0f, 5.0f, 0.1f, "x");
        AddFloat("Air Speed", 1.2f, 1.0f, 3.0f, 0.1f, "x");
        AddMode("Mode", {"Strafe", "Vanilla", "BHop"}, 0);
        AddBool("Speed in Air", true);
        SetColor(0.2f, 0.9f, 0.5f);
    }
    
    void OnEnable() override {}
    void OnDisable() override {}
    void OnPlayerTick(void* player) override;
};

} // namespace Nexus
