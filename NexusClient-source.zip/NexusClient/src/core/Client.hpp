#pragma once
/**
 * Client.hpp — Singleton managing all client subsystems.
 * Central hub for modules, config, events, and rendering.
 */

#include <memory>
#include <vector>
#include <string>
#include <unordered_map>
#include <functional>

#include "../modules/Module.hpp"
#include "../config/ConfigManager.hpp"
#include "EventBus.hpp"

namespace Nexus {

class Client {
public:
    static Client& GetInstance() {
        static Client instance;
        return instance;
    }
    
    // Delete copy/move
    Client(const Client&) = delete;
    Client& operator=(const Client&) = delete;
    
    /**
     * Initialize all subsystems:
     *  1. Pattern scanner cache
     *  2. Module registration
     *  3. Config loading
     *  4. GUI setup
     */
    void Init();
    
    /**
     * Shutdown cleanly — unhook everything, save config.
     */
    void Shutdown();
    
    // Module management
    void RegisterModule(std::unique_ptr<Module> module);
    Module* GetModule(const std::string& name);
    
    template<typename T>
    T* GetModule() {
        for (auto& mod : m_modules) {
            if (auto* casted = dynamic_cast<T*>(mod.get()))
                return casted;
        }
        return nullptr;
    }
    
    const std::vector<std::unique_ptr<Module>>& GetModules() const { return m_modules; }
    
    // Category-based access
    std::vector<Module*> GetModulesByCategory(Module::Category cat) const;
    
    // Event system
    EventBus& GetEventBus() { return m_eventBus; }
    
    // Config system
    ConfigManager& GetConfigManager() { return m_configManager; }
    
    // State
    bool IsInitialized() const { return m_initialized; }
    
private:
    Client() = default;
    ~Client() = default;
    
    void RegisterAllModules();
    
    std::vector<std::unique_ptr<Module>> m_modules;
    EventBus m_eventBus;
    ConfigManager m_configManager;
    bool m_initialized = false;
};

} // namespace Nexus
