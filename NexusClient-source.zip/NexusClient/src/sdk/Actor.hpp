#pragma once
/**
 * Actor.hpp — Bedrock Actor/Entity class interface.
 * All offsets resolved via pattern scanning at runtime.
 */

#include <string>
#include "../core/Memory.hpp"

namespace Nexus::SDK {

struct Vec3 {
    float x, y, z;
    
    Vec3 operator+(const Vec3& o) const { return {x+o.x, y+o.y, z+o.z}; }
    Vec3 operator-(const Vec3& o) const { return {x-o.x, y-o.y, z-o.z}; }
    Vec3 operator*(float s) const { return {x*s, y*s, z*s}; }
    float length() const;
    float distanceTo(const Vec3& o) const;
};

struct Vec2 {
    float x, y; // pitch, yaw
};

struct AABB {
    Vec3 min, max;
    Vec3 center() const { return (min + max) * 0.5f; }
};

/**
 * Actor — base entity class in Bedrock.
 * VTable indices found via signature scanning.
 */
class Actor {
public:
    // Position
    Vec3* getPosition();
    Vec3* getVelocity();
    void setPosition(const Vec3& pos);
    void setVelocity(const Vec3& vel);
    
    // Rotation
    Vec2* getRotation();
    void setRotation(const Vec2& rot);
    
    // Properties
    float getHealth();
    float getMaxHealth();
    bool isAlive();
    bool isPlayer();
    bool isMob();
    bool isOnGround();
    bool isInWater();
    bool isInvisible();
    
    // Bounding box
    AABB* getAABB();
    
    // Name
    std::string getNameTag();
    
    // Type
    int getEntityTypeId();
    
    // Runtime ID
    uint64_t getRuntimeID();
    
    // Dimensions
    float getHeadHeight();

private:
    // VTable call helper
    template<typename Ret, typename... Args>
    Ret callVirtual(int index, Args... args) {
        auto vtable = *reinterpret_cast<uintptr_t**>(this);
        auto func = reinterpret_cast<Ret(*)(void*, Args...)>(vtable[index]);
        return func(this, args...);
    }
};

} // namespace Nexus::SDK
