#pragma once
#include "../Module.hpp"

namespace Nexus {

class Weather : public Module {
public:
    Weather() : Module("Weather", "Control weather rendering",
                       Category::World) {
        AddMode("Mode", {"Clear", "Rain", "Thunder", "Lock"}, 0);
        SetColor(0.5f, 0.7f, 1.0f);
    }
    
    void OnEnable() override;
    void OnDisable() override;
    void OnLevelTick(void* level) override;
};

} // namespace Nexus
