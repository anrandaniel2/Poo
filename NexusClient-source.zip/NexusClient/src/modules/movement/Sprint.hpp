#pragma once
#include "../Module.hpp"

namespace Nexus {

class Sprint : public Module {
public:
    Sprint() : Module("Sprint", "Automatically sprints",
                      Category::Movement) {
        AddMode("Mode", {"Legit", "Omni", "Rage"}, 0);
        SetColor(0.3f, 0.8f, 0.4f);
    }
    
    void OnEnable() override {}
    void OnDisable() override {}
    void OnPlayerTick(void* player) override;
};

} // namespace Nexus
